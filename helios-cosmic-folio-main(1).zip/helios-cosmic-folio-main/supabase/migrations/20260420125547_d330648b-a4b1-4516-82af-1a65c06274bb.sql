create table public.contact_submissions (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  subject text,
  message text not null,
  created_at timestamptz not null default now()
);

alter table public.contact_submissions enable row level security;

-- Anyone (anon) can insert a submission (public contact form)
create policy "Anyone can submit contact form"
on public.contact_submissions
for insert
to anon, authenticated
with check (
  length(name) between 1 and 100
  and length(email) between 3 and 255
  and length(message) between 1 and 5000
);

-- Only authenticated users (you, via the dashboard) can read
create policy "Authenticated can read submissions"
on public.contact_submissions
for select
to authenticated
using (true);

create index contact_submissions_created_at_idx on public.contact_submissions (created_at desc);