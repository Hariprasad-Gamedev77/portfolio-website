// EDIT THIS FILE to update your portfolio.
// Just add a new object to the `projects` array — the layout updates automatically.

export type ProjectCategory = "Level Design" | "Mechanics" | "Blockouts";

export interface MediaClip {
  title: string;
  /** MP4/WebM URL or YouTube/Vimeo URL — VideoPlayer handles both. */
  videoUrl: string;
  description?: string;
  poster?: string;
}

export interface ProcessStep {
  label: string; // e.g. "01 — Reference"
  title: string;
  body: string;
  image?: string;
  /** Optional video for this step (MP4 or YouTube). */
  videoUrl?: string;
}

export interface GalleryImage {
  src: string;
  caption?: string;
}

export interface DesignTechnique {
  title: string;
  body: string;
  image?: string;
  videoUrl?: string;
}

export interface Project {
  id: string;
  title: string;
  category: ProjectCategory;
  thumbnail: string;
  /** Trailer / hero video shown at the top of the project page. MP4 or YouTube. */
  heroVideo: string;
  /** Tension graph / full playthrough — usually a YouTube link. */
  tensionGraphVideo?: string;
  walkthroughVideo?: string;
  role: string;
  engine: string;
  duration: string;
  year: string;
  client?: string;
  description: string;
  summary: string;
  challenge: string;
  approach: string;
  outcome: string;
  designIntent: string;
  topDownMapImage: string;
  designTechniques: DesignTechnique[];
  references: GalleryImage[];
  sketches: GalleryImage[];
  blockoutVideo?: string;
  blockoutNotes?: string;
  environmentalStorytelling: GalleryImage[];
  environmentalStorytellingNotes?: string;
  process: ProcessStep[];
  gallery: GalleryImage[];
  gameplayClips: MediaClip[];
  reflection?: string;
}

// Placeholder media — swap these URLs with your own.
const PLACEHOLDER_VIDEO =
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4";
const PLACEHOLDER_REEL =
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4";

export const heroReel = PLACEHOLDER_REEL;

// ─────────────────────────────────────────────────────────────
// Personal info — edit these strings to update the whole site.
// ─────────────────────────────────────────────────────────────
export const profile = {
  firstName: "Hariprasad",
  fullName: "Hariprasad M",
  role: "Level Designer",
  studio: "Dreamspire Realm Studio",
  flagshipProject: "Eclipse Chronicles",
  education: "B.Tech CSE · SRM IST Trichy, India",
  location: "Trichy, India",
  workMode: "Available",
  email: "hariprasadmviiie@gmail.com",
  linkedin: "https://www.linkedin.com/in/hariprasad-gamedev/",
  github: "https://github.com/",
  // CV is served from /public — replace the file at public/hariprasad-cv.pdf to update.
  cvUrl: "/hariprasad-cv.pdf",
};

// ─────────────────────────────────────────────────────────────
// Experience — edit/add roles here.
// ─────────────────────────────────────────────────────────────
export interface ExperienceItem {
  role: string;
  company: string;
  type: string; // Founder · Internship · Freelance
  start: string; // "Jan 2024"
  end: string;  // "Present"
  location: string;
  summary: string;
}

export const experience: ExperienceItem[] = [
  {
    role: "Founder & Game Director",
    company: "Dreamspire Realm Studio",
    type: "Founder",
    start: "2023",
    end: "Present",
    location: "Trichy, India",
    summary:
      "Founded an indie studio shipping Eclipse Chronicles — a cinematic RPG built in Unreal Engine 5. Lead level design, world building, and core gameplay scripting.",
  },
  {
    role: "B.Tech, Computer Science & Engineering",
    company: "SRM IST Trichy",
    type: "Education",
    start: "2025",
    end: "2029",
    location: "Trichy, India",
    summary:
      "Pursuing a B.Tech in CSE while building games full-time on the side — focusing on systems design, graphics, and real-time engines.",
  },
];

// ─────────────────────────────────────────────────────────────
// Certifications — shown on /certifications.
// `proofUrl` can be an image URL (jpg/png/webp) or a PDF link.
// Images get a thumbnail + lightbox; PDFs get a "View PDF" button.
// ─────────────────────────────────────────────────────────────
export interface Certification {
  title: string;
  issuer: string;
  year: string;
  credentialUrl?: string;
  description?: string;
  /** Image URL (jpg/png/webp) OR PDF URL of the certificate. */
  proofUrl?: string;
}

export const certifications: Certification[] = [
  {
    title: "Unreal Engine 5 — Level Design Fundamentals",
    issuer: "Epic Online Learning",
    year: "2024",
    description:
      "Worldbuilding, BSP blockouts, and pacing principles in UE5.",
    // Replace with your actual cert image or PDF link
    proofUrl:
      "https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?w=1600&q=80",
  },
  {
    title: "Blueprint Scripting for Game Designers",
    issuer: "Unreal Online Learning",
    year: "2024",
    description:
      "Visual scripting fundamentals — encounters, triggers, and gameplay state.",
    proofUrl:
      "https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?w=1600&q=80",
  },
  {
    title: "C++ Programming Essentials",
    issuer: "Coursera",
    year: "2023",
    description: "Foundations of modern C++ used for engine-side gameplay code.",
  },
  {
    title: "Game Design & Theory",
    issuer: "Self-issued · Workshop",
    year: "2023",
    description:
      "Player psychology, level pacing, and economy design — replace with the real cert.",
  },
];

// ─────────────────────────────────────────────────────────────
// Reusable defaults — keeps each project block readable.
// Override on a per-project basis by adding the field directly.
// ─────────────────────────────────────────────────────────────
const defaultProcess: ProcessStep[] = [
  {
    label: "01 — Reference",
    title: "Mood & intent.",
    body: "Start from a single emotional anchor — a feeling I want the player to carry through the level. Pull references from architecture, film, and existing games to lock the visual language before any geometry is placed.",
    image:
      "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=1600&q=80",
  },
  {
    label: "02 — Paper Map",
    title: "Layout on paper.",
    body: "Sketch the macro flow as a 2D map: critical path, optional loops, sightline anchors, and rest beats. The paper version forces every space to justify itself before the engine eats time.",
    image:
      "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=1600&q=80",
  },
  {
    label: "03 — Greybox",
    title: "Blockout in engine.",
    body: "Translate the paper map into a UE5 blockout using BSP and primitive meshes. Movement, scale, and pacing are tuned over dozens of playtest passes — geometry stays disposable until the rhythm feels right.",
    image:
      "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=1600&q=80",
  },
  {
    label: "04 — Scripting",
    title: "Triggers & encounters.",
    body: "Layer in Blueprints for triggers, encounter logic, and cinematic moments. Every script is built to be easy to tune — exposed variables over hardcoded values so playtesters can dial intensity in seconds.",
    image:
      "https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=1600&q=80",
  },
  {
    label: "05 — Polish",
    title: "Lighting & feel.",
    body: "Final pass on lighting, post-process, and audio cues to lock the mood. The level only ships once the first 30 seconds make a stranger lean forward.",
    image:
      "https://images.unsplash.com/photo-1614851099175-e5b30eb6f696?w=1600&q=80",
  },
];

const defaultDesignTechniques: DesignTechnique[] = [
  {
    title: "Sightline composition",
    body: "Every key turn frames the level's anchor — the eclipse, the spire, the goal. Players never need a UI marker to know where they're going.",
    image:
      "https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=1600&q=80",
  },
  {
    title: "Pacing rhythm",
    body: "Tension is shaped in 4-beat cycles: silence → signal → threat → release. Repetition with escalation lets dread compound without scripted set-pieces.",
    image:
      "https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=1600&q=80",
  },
  {
    title: "Affordance language",
    body: "A consistent visual vocabulary — what's climbable, what's cover, what's hostile — built from material, silhouette, and light, never icons.",
    image:
      "https://images.unsplash.com/photo-1614851099175-e5b30eb6f696?w=1600&q=80",
  },
];

const defaultReferences: GalleryImage[] = [
  { src: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=1600&q=80", caption: "Architectural mass — citadel inspiration" },
  { src: "https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=1600&q=80", caption: "Skyline silhouette study" },
  { src: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1600&q=80", caption: "Lighting reference — eclipse mood" },
];

const defaultSketches: GalleryImage[] = [
  { src: "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=1600&q=80", caption: "Paper map — pass 01" },
  { src: "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=1600&q=80", caption: "Paper map — pass 03 with patrol overlays" },
];

const defaultEnvStorytelling: GalleryImage[] = [
  {
    src: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=1600&q=80",
    caption: "Aftermath of the gate breach — props tell the fight you didn't see.",
  },
  {
    src: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1600&q=80",
    caption: "Vendor stall, abandoned mid-trade — light still on.",
  },
];

export const projects: Project[] = [
  {
    id: "eclipse-chronicles",
    title: "Eclipse Chronicles",
    category: "Level Design",
    thumbnail:
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=1200&q=80",
    heroVideo: PLACEHOLDER_VIDEO,
    walkthroughVideo: PLACEHOLDER_VIDEO,
    tensionGraphVideo: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    role: "Founder · Lead Designer",
    engine: "Unreal Engine 5",
    duration: "Ongoing",
    year: "2024",
    client: "Dreamspire Realm Studio",
    description:
      "A cinematic third-person RPG set during a perpetual solar eclipse. The flagship title of Dreamspire Realm Studio — players navigate a fractured celestial citadel where light and shadow drive every encounter.",
    summary:
      "A vertical hub level for Eclipse Chronicles where the eclipse itself is the player's compass. Three traversal rings, no UI markers, every sightline tuned so progress is read through light alone.",
    challenge:
      "Build a vertical hub level that stays legible across three traversal rings without ever hiding the eclipse — the player's only true compass.",
    approach:
      "Anchored every sightline to the eclipse and tuned silhouette readability so cover, gates, and goals each occupy a distinct visual register.",
    outcome:
      "Average playtest completion dropped from 47 to 28 minutes with zero UI markers — players self-navigated using light cues alone.",
    designIntent:
      "The level is structured around three rings of vertical traversal, each gated by a celestial mechanic. Sightlines are tuned so the eclipse always anchors the player's compass — wherever you are, looking up reveals progress.",
    topDownMapImage:
      "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=1600&q=80",
    designTechniques: defaultDesignTechniques,
    references: defaultReferences,
    sketches: defaultSketches,
    blockoutVideo: PLACEHOLDER_VIDEO,
    blockoutNotes:
      "BSP-first blockout, tuned over 14 playtest passes. Mesh swap was held back until the rhythm and scale locked — geometry stayed disposable on purpose.",
    environmentalStorytelling: defaultEnvStorytelling,
    environmentalStorytellingNotes:
      "Every prop earns its place by hinting at a story the player isn't told directly — toppled banners, half-burned offerings, footprints leading nowhere.",
    process: defaultProcess,
    gallery: [
      { src: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1600&q=80", caption: "Eclipse gate · final lighting pass" },
      { src: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1600&q=80", caption: "Inner ring traversal · greybox to final" },
      { src: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1600&q=80", caption: "Sightline study · top of citadel" },
      { src: "https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=1600&q=80", caption: "Approach corridor · player POV" },
    ],
    gameplayClips: [
      { title: "Eclipse Gate Encounter", videoUrl: PLACEHOLDER_VIDEO, description: "Light/shadow puzzle gating the second ring." },
      { title: "Citadel Traversal", videoUrl: PLACEHOLDER_VIDEO, description: "Vertical parkour sequence with dynamic camera framing." },
    ],
    reflection:
      "Eclipse Chronicles taught me that a single visual anchor can replace half a UI. When the world itself answers 'where do I go?', the player stops reading and starts believing.",
  },
  {
    id: "void-runner",
    title: "Void Runner",
    category: "Mechanics",
    thumbnail:
      "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=1200&q=80",
    heroVideo: PLACEHOLDER_VIDEO,
    walkthroughVideo: PLACEHOLDER_VIDEO,
    role: "Gameplay & Systems Designer",
    engine: "Unreal Engine 5 · Blueprints",
    duration: "4 months",
    year: "2024",
    description:
      "A high-velocity movement prototype exploring momentum-based traversal across modular space platforms.",
    summary:
      "One verb, three contexts. Dash mastery emerges from layering — not from new inputs.",
    challenge:
      "Make a single verb feel like three without overloading the input layer or breaking momentum across context switches.",
    approach:
      "Built dash as a layered Blueprint state machine — context (wall, gravity field, chain) modifies the same root verb instead of stacking new inputs.",
    outcome:
      "Players reached the chain-dash mastery loop within 4 minutes on average — a 3× improvement over the previous input-heavy prototype.",
    designIntent:
      "Built around a single verb — dash — extended through context: wall-dash, gravity-dash, and chain-dash. Each level is a sandbox testing a single permutation before combining all three.",
    topDownMapImage:
      "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1600&q=80",
    designTechniques: defaultDesignTechniques,
    references: defaultReferences,
    sketches: defaultSketches,
    blockoutVideo: PLACEHOLDER_VIDEO,
    environmentalStorytelling: defaultEnvStorytelling,
    process: defaultProcess,
    gallery: [
      { src: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1600&q=80", caption: "Wall-dash test bed" },
      { src: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1600&q=80", caption: "Chain-dash arena · final layout" },
    ],
    gameplayClips: [
      { title: "Chain-Dash Sequence", videoUrl: PLACEHOLDER_VIDEO, description: "Three-link dash chain across modular platforms." },
    ],
  },
  {
    id: "stellar-keep",
    title: "Stellar Keep — Blockout",
    category: "Blockouts",
    thumbnail:
      "https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=1200&q=80",
    heroVideo: PLACEHOLDER_VIDEO,
    walkthroughVideo: PLACEHOLDER_VIDEO,
    role: "Level Designer",
    engine: "Unreal Engine 5",
    duration: "6 weeks",
    year: "2024",
    description:
      "A greybox of a fortified observatory perched above a starfield canyon. Focused on combat arena pacing and sniper sightlines.",
    summary:
      "An arena that reads the same from three asymmetric approaches — flank parity tested across 40+ AI runs.",
    challenge:
      "Design a single arena that reads cleanly from three asymmetric approaches without privileging any one route.",
    approach:
      "Three tiers of cover rotated 120° around a central spire — every flank gives equal information at equal cost.",
    outcome:
      "AI playtests across 40+ runs showed within-5% engagement parity across all three approaches.",
    designIntent:
      "Three tiers of cover — low, mid, hard — rotated 120° so every approach offers a unique flank. Tested with 40+ AI runs to balance sightline coverage.",
    topDownMapImage:
      "https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=1600&q=80",
    designTechniques: defaultDesignTechniques,
    references: defaultReferences,
    sketches: defaultSketches,
    blockoutVideo: PLACEHOLDER_VIDEO,
    environmentalStorytelling: defaultEnvStorytelling,
    process: defaultProcess,
    gallery: [
      { src: "https://images.unsplash.com/photo-1532968961962-8a0cb3a2d4f5?w=1600&q=80", caption: "Approach A · cover rotation study" },
      { src: "https://images.unsplash.com/photo-1581822261290-991b38693d1b?w=1600&q=80", caption: "Spire central · sightline heatmap" },
    ],
    gameplayClips: [
      { title: "Arena Flow Test", videoUrl: PLACEHOLDER_VIDEO, description: "Three-approach AI playtest pass." },
    ],
  },
  {
    id: "lunar-descent",
    title: "Lunar Descent",
    category: "Level Design",
    thumbnail:
      "https://images.unsplash.com/photo-1532968961962-8a0cb3a2d4f5?w=1200&q=80",
    heroVideo: PLACEHOLDER_VIDEO,
    walkthroughVideo: PLACEHOLDER_VIDEO,
    role: "Solo Designer",
    engine: "Unreal Engine 5",
    duration: "3 months",
    year: "2023",
    description:
      "A vertical descent through a hollowed moon, trading visibility for verticality as the player falls deeper into the core.",
    summary:
      "Sustained dread across 25 minutes by structure — silence, signal, threat, release — repeated three times with escalating stakes.",
    challenge:
      "Sustain dread across a 25-minute descent without relying on jump scares or scripted set pieces.",
    approach:
      "Pacing follows a 4-beat structure: silence, signal, threat, release — repeated three times with escalating stakes.",
    outcome:
      "Playtesters consistently reported peak tension at the third repetition — the structure landed without any hand-holding.",
    designIntent:
      "Pacing follows a 4-beat structure: silence, signal, threat, release — repeated three times with escalating stakes.",
    topDownMapImage:
      "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1600&q=80",
    designTechniques: defaultDesignTechniques,
    references: defaultReferences,
    sketches: defaultSketches,
    blockoutVideo: PLACEHOLDER_VIDEO,
    environmentalStorytelling: defaultEnvStorytelling,
    process: defaultProcess,
    gallery: [
      { src: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1600&q=80", caption: "Mid-descent rest beat" },
      { src: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1600&q=80", caption: "Core arrival · final lighting" },
    ],
    gameplayClips: [
      { title: "Core Descent", videoUrl: PLACEHOLDER_VIDEO, description: "Final 90 seconds of the descent loop." },
    ],
  },
  {
    id: "gravity-well",
    title: "Gravity Well",
    category: "Mechanics",
    thumbnail:
      "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1200&q=80",
    heroVideo: PLACEHOLDER_VIDEO,
    walkthroughVideo: PLACEHOLDER_VIDEO,
    role: "Mechanics Designer",
    engine: "Unreal Engine 5 · Blueprints",
    duration: "5 weeks",
    year: "2023",
    description:
      "A physics sandbox where players bend local gravity to redirect projectiles, enemies, and themselves.",
    summary:
      "A single physics primitive expressive enough to power 12 distinct encounters — iteration time per encounter dropped ~70%.",
    challenge:
      "Make a single physics primitive expressive enough to power an entire encounter library.",
    approach:
      "Built a parameterized gravity volume Blueprint with falloff, polarity, and shape exposed — every encounter remixes the same actor.",
    outcome:
      "Shipped 12 distinct encounters from a single reusable actor — cut iteration time per encounter by ~70%.",
    designIntent:
      "Designed the core gravity volume as a reusable Blueprint actor with tunable falloff — every encounter is composed from the same primitive.",
    topDownMapImage:
      "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1600&q=80",
    designTechniques: defaultDesignTechniques,
    references: defaultReferences,
    sketches: defaultSketches,
    blockoutVideo: PLACEHOLDER_VIDEO,
    environmentalStorytelling: defaultEnvStorytelling,
    process: defaultProcess,
    gallery: [
      { src: "https://images.unsplash.com/photo-1543722530-d2c3201371e7?w=1600&q=80", caption: "Volume falloff visualization" },
    ],
    gameplayClips: [
      { title: "Gravity Redirect", videoUrl: PLACEHOLDER_VIDEO, description: "Player redirecting incoming projectiles." },
    ],
  },
  {
    id: "horizon-outpost",
    title: "Horizon Outpost — Blockout",
    category: "Blockouts",
    thumbnail:
      "https://images.unsplash.com/photo-1581822261290-991b38693d1b?w=1200&q=80",
    heroVideo: PLACEHOLDER_VIDEO,
    walkthroughVideo: PLACEHOLDER_VIDEO,
    role: "Level Designer",
    engine: "Unreal Engine 5",
    duration: "4 weeks",
    year: "2023",
    description:
      "A research outpost greybox built to test stealth pacing across long sightlines and overlapping patrol routes.",
    summary:
      "Stealth taught by patrol rhythm — no UI markers needed. Stealth-only completion jumped 31% → 78% after rework.",
    challenge:
      "Make stealth readable without any UI markers — the patrol rhythm itself has to teach the player.",
    approach:
      "Patrol loops intersect at predictable beats so players can read the rhythm without UI assistance.",
    outcome:
      "Stealth-only completion rate jumped from 31% to 78% across blind playtests after the patrol-rhythm rework.",
    designIntent:
      "Patrol loops intersect at predictable beats so players can read the rhythm without UI assistance.",
    topDownMapImage:
      "https://images.unsplash.com/photo-1454789548928-9efd52dc4031?w=1600&q=80",
    designTechniques: defaultDesignTechniques,
    references: defaultReferences,
    sketches: defaultSketches,
    blockoutVideo: PLACEHOLDER_VIDEO,
    environmentalStorytelling: defaultEnvStorytelling,
    process: defaultProcess,
    gallery: [
      { src: "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=1600&q=80", caption: "Patrol intersection · top-down study" },
    ],
    gameplayClips: [
      { title: "Patrol Loop Demo", videoUrl: PLACEHOLDER_VIDEO, description: "Two patrols intersecting on a 12-second cadence." },
    ],
  },
];

export type SkillProficiency = "Advanced" | "Intermediate" | "Familiar";

export const skills: { name: string; proficiency: SkillProficiency }[] = [
  { name: "Unreal Engine 5", proficiency: "Familiar" },
  { name: "Level Blockout", proficiency: "Familiar" },
  { name: "Blueprints Scripting", proficiency: "Familiar" },
  { name: "Lighting & Post-Process", proficiency: "Familiar" },
  { name: "Worldbuilding & Narrative", proficiency: "Familiar" },
  { name: "C++", proficiency: "Familiar" },
];

export const typingPhrases = [
  "Level Designer",
  "World Builder",
  "Unreal Engine 5",
  "Worldcrafter",
];
