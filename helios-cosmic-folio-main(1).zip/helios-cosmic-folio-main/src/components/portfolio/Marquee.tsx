export function Marquee() {
  return (
    <section className="overflow-hidden border-y border-border bg-background py-8">
      <div className="marquee-track flex w-max animate-marquee whitespace-nowrap">
        {[0, 1].map((dup) => (
          <div key={dup} className="flex items-center gap-12 pr-12" aria-hidden={dup === 1}>
            {[
              "Game Development",
              "Unreal Engine 5",
              "Eclipse Chronicles",
              "Level Design",
              "Blueprints",
              "Worldbuilding",
            ].map((word, i) => (
              <span
                key={`${dup}-${i}`}
                className="font-serif text-5xl italic text-foreground md:text-7xl"
              >
                {word}
                <span className="mx-8 text-muted-foreground">✦</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}
