import { motion } from "framer-motion";
import { skills, type SkillProficiency } from "@/data/portfolio";

const proficiencyMeta: Record<
  SkillProficiency,
  { dots: number; rank: number; tone: string; bar: string; label: string }
> = {
  Advanced: {
    dots: 3,
    rank: 3,
    tone: "text-foreground",
    bar: "bg-foreground",
    label: "Advanced",
  },
  Intermediate: {
    dots: 2,
    rank: 2,
    tone: "text-foreground/80",
    bar: "bg-foreground/70",
    label: "Intermediate",
  },
  Familiar: {
    dots: 1,
    rank: 1,
    tone: "text-muted-foreground",
    bar: "bg-muted-foreground/60",
    label: "Familiar · Learning",
  },
};

export function Skills() {
  return (
    <section id="skills" className="border-t border-border bg-background py-32">
      <div className="mx-auto max-w-7xl px-8">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-3">
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              (02) Tools
            </p>
            <p className="mt-6 hidden max-w-[14rem] text-xs leading-relaxed text-muted-foreground md:block">
              An honest snapshot of what I reach for daily and what I'm still
              sharpening.
            </p>
          </div>

          <div className="md:col-span-9">
            <h2 className="font-serif text-4xl leading-[1.05] text-foreground md:text-6xl">
              Tools <span className="font-serif-italic">of the trade.</span>
            </h2>

            <div className="mt-16 border-y border-border">
              {skills.map((s, idx) => {
                const meta = proficiencyMeta[s.proficiency];
                const isFamiliar = s.proficiency === "Familiar";
                const widthPct = (meta.rank / 3) * 100;

                return (
                  <motion.div
                    key={s.name}
                    initial={{ opacity: 0, y: 12 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.5, delay: idx * 0.05 }}
                    className="group relative border-t border-border first:border-t-0"
                  >
                    {/* Bottom proficiency bar */}
                    <motion.span
                      aria-hidden
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: widthPct / 100 }}
                      viewport={{ once: true, margin: "-50px" }}
                      transition={{
                        duration: 0.9,
                        delay: idx * 0.05 + 0.2,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                      className={`pointer-events-none absolute bottom-0 left-0 h-px origin-left ${meta.bar}`}
                      style={{ width: "100%" }}
                    />

                    <div className="grid grid-cols-12 items-center gap-4 py-6 transition-colors">
                      <span className="col-span-1 text-xs text-muted-foreground">
                        {String(idx + 1).padStart(2, "0")}
                      </span>
                      <span
                        className={`col-span-7 font-serif text-2xl transition-colors duration-500 md:text-4xl ${
                          isFamiliar
                            ? "italic text-muted-foreground group-hover:text-foreground"
                            : "text-foreground"
                        }`}
                      >
                        {s.name}
                      </span>

                      <div className="col-span-2 hidden items-center gap-1.5 md:flex">
                        {[0, 1, 2].map((i) => {
                          const active = i < meta.dots;
                          return (
                            <motion.span
                              key={i}
                              initial={{ scale: 0.6, opacity: 0 }}
                              whileInView={{ scale: 1, opacity: 1 }}
                              viewport={{ once: true, margin: "-50px" }}
                              transition={{
                                duration: 0.4,
                                delay: idx * 0.05 + 0.3 + i * 0.08,
                              }}
                              className={`h-1.5 w-1.5 rounded-full ${
                                active ? meta.bar : "bg-border"
                              } ${
                                isFamiliar && active
                                  ? "ring-1 ring-muted-foreground/40 ring-offset-2 ring-offset-background"
                                  : ""
                              }`}
                            />
                          );
                        })}
                      </div>

                      <span
                        className={`col-span-4 text-right text-[0.65rem] uppercase tracking-[0.2em] md:col-span-2 ${meta.tone}`}
                      >
                        {meta.label}
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-[0.65rem] uppercase tracking-[0.25em] text-muted-foreground">
              <LegendDot label="Advanced" tone="bg-foreground" />
              <LegendDot label="Intermediate" tone="bg-foreground/70" />
              <LegendDot
                label="Familiar · still learning"
                tone="bg-muted-foreground/60"
                ringed
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function LegendDot({
  label,
  tone,
  ringed,
}: {
  label: string;
  tone: string;
  ringed?: boolean;
}) {
  return (
    <span className="inline-flex items-center gap-2">
      <span
        className={`h-1.5 w-1.5 rounded-full ${tone} ${
          ringed
            ? "ring-1 ring-muted-foreground/40 ring-offset-2 ring-offset-background"
            : ""
        }`}
      />
      {label}
    </span>
  );
}
