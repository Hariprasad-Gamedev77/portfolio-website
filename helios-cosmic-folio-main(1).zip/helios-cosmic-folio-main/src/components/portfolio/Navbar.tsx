import { useEffect, useState } from "react";
import { Menu, X, FileText } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { profile } from "@/data/portfolio";

const links = [
  { href: "/#about", label: "About" },
  { href: "/#skills", label: "Tools" },
  { href: "/#work", label: "Projects" },
  { href: "/certifications", label: "Certifications" },
  { href: "/#contact", label: "Contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-background/80 backdrop-blur-md border-b border-border"
          : "bg-transparent"
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-8 py-6">
        <Link to="/" className="group flex items-baseline gap-2">
          <span className="font-serif text-2xl text-foreground">Hariprasad</span>
          <span className="hidden text-xs uppercase tracking-[0.3em] text-muted-foreground sm:inline">
            / Level Designer
          </span>
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          <ul className="flex items-center gap-8">
            {links.map((l) => (
              <li key={l.href}>
                {l.href.startsWith("/#") ? (
                  <a
                    href={l.href}
                    className="relative text-sm uppercase tracking-[0.2em] text-foreground transition-opacity hover:opacity-60"
                  >
                    {l.label}
                  </a>
                ) : (
                  <Link
                    to={l.href}
                    className="relative text-sm uppercase tracking-[0.2em] text-foreground transition-opacity hover:opacity-60"
                  >
                    {l.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>
          <a
            href="/#contact"
            className="inline-flex items-center gap-2 rounded-full border border-foreground bg-foreground px-5 py-2 text-xs uppercase tracking-[0.2em] text-background transition-colors hover:bg-transparent hover:text-foreground"
          >
            Let's talk
          </a>
        </div>

        <button
          className="md:hidden text-foreground"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden border-t border-border bg-background">
          <ul className="flex flex-col px-8 py-6">
            {links.map((l) => (
              <li key={l.href}>
                {l.href.startsWith("/#") ? (
                  <a
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="block py-3 text-sm uppercase tracking-[0.2em] text-foreground"
                  >
                    {l.label}
                  </a>
                ) : (
                  <Link
                    to={l.href}
                    onClick={() => setOpen(false)}
                    className="block py-3 text-sm uppercase tracking-[0.2em] text-foreground"
                  >
                    {l.label}
                  </Link>
                )}
              </li>
            ))}
            <li>
              <a
                href={profile.cvUrl}
                target="_blank"
                rel="noreferrer"
                onClick={() => setOpen(false)}
                className="flex items-center gap-2 py-3 text-sm uppercase tracking-[0.2em] text-foreground"
              >
                <FileText size={14} />
                Download Resume
              </a>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
