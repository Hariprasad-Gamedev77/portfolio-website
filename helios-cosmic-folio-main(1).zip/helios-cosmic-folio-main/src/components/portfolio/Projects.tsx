import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { projects, type ProjectCategory } from "@/data/portfolio";
import { ProjectCard } from "./ProjectCard";

const filters: ("All" | ProjectCategory)[] = [
  "All",
  "Level Design",
  "Mechanics",
  "Blockouts",
];

export function Projects() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");

  const visible = useMemo(() => {
    const flagship = projects.find((p) => p.id === "eclipse-chronicles");
    const rest = projects.filter((p) => p.id !== "eclipse-chronicles");
    const filtered =
      filter === "All" ? rest : rest.filter((p) => p.category === filter);
    return flagship ? [flagship, ...filtered] : filtered;
  }, [filter]);

  return (
    <section id="work" className="border-t border-border bg-background py-32">
      <div className="mx-auto max-w-7xl px-8">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-3">
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              (01) The Work
            </p>
          </div>
          <div className="md:col-span-9">
            <h2 className="font-serif text-4xl leading-[1.05] text-foreground md:text-6xl">
              Worlds I've <span className="font-serif-italic">shaped.</span>
            </h2>

            <div className="mt-10 flex flex-wrap items-center gap-1 border-b border-border pb-4">
              {filters.map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`relative px-4 py-2 text-xs uppercase tracking-[0.2em] transition-colors ${
                    filter === f
                      ? "text-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {f}
                  {filter === f && (
                    <motion.span
                      layoutId="filter-underline"
                      className="absolute -bottom-[17px] left-0 right-0 h-px bg-foreground"
                    />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        <motion.div
          layout
          className="mt-20 grid gap-x-10 gap-y-24 md:grid-cols-2"
        >
          <AnimatePresence mode="popLayout">
            {visible.map((p, i) => (
              <ProjectCard key={p.id} project={p} index={i} />
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
