import { motion } from "framer-motion";
import { experience } from "@/data/portfolio";

export function Experience() {
  return (
    <section
      id="experience"
      className="border-t border-border bg-background py-32"
    >
      <div className="mx-auto max-w-7xl px-8">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-3">
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              (04) Experience
            </p>
          </div>
          <div className="md:col-span-9">
            <h2 className="font-serif text-4xl leading-[1.05] text-foreground md:text-6xl">
              What I've been{" "}
              <span className="font-serif-italic">building.</span>
            </h2>

            <div className="mt-12 divide-y divide-border border-y border-border">
              {experience.map((item, idx) => (
                <motion.div
                  key={`${item.company}-${idx}`}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.5, delay: idx * 0.08 }}
                  className="grid gap-4 py-8 md:grid-cols-12 md:gap-8"
                >
                  <div className="md:col-span-3">
                    <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
                      {item.start} — {item.end}
                    </p>
                    <p className="mt-1 text-xs uppercase tracking-[0.2em] text-muted-foreground">
                      {item.type}
                    </p>
                  </div>
                  <div className="md:col-span-9">
                    <h3 className="font-serif text-2xl text-foreground md:text-3xl">
                      {item.role}
                    </h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      <span className="font-serif-italic">{item.company}</span>{" "}
                      · {item.location}
                    </p>
                    <p className="mt-3 max-w-2xl text-base leading-relaxed text-foreground">
                      {item.summary}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
