import { motion } from "framer-motion";
import { profile } from "@/data/portfolio";

export function About() {
  return (
    <section id="about" className="border-t border-border bg-background py-32">
      <div className="mx-auto max-w-7xl px-8">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-3">
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              (03) About
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
            className="md:col-span-9"
          >
            <h2 className="font-serif text-4xl leading-[1.05] text-foreground md:text-6xl">
              I craft <span className="font-serif-italic">intuitive</span>{" "}
              worlds where every corner —{" "}
              <span className="font-serif-italic">structure, pathing, light</span>{" "}
              — guides the player without ever telling them.
            </h2>

            <div className="mt-12 grid gap-10 text-base leading-relaxed text-foreground md:grid-cols-2">
              <p>
                I'm Hariprasad, a{" "}
                <span className="font-serif-italic">Level Designer</span>{" "}
                dedicated to crafting immersive gameplay environments that
                enhance player experience through strong layout design, pacing,
                and environmental storytelling. My focus sits at the
                intersection of{" "}
                <span className="font-serif-italic">player navigation</span>,
                encounter design, and worldbuilding through space.
              </p>
              <p>
                I design levels that communicate clearly without relying on
                explicit instruction — letting players learn, explore, and
                engage naturally. Every element, from structure to pathing to
                interaction, contributes to a cohesive, memorable journey.
                Currently I'm developing{" "}
                <span className="font-serif-italic">Eclipse Chronicles</span>,
                an open-world project centered on exploration, narrative depth,
                and interconnected level design — built at{" "}
                <span className="font-serif-italic">{profile.studio}</span>{" "}
                while pursuing my{" "}
                <span className="font-serif-italic">{profile.education}</span>.
              </p>
            </div>

            <div className="mt-12 flex flex-wrap items-center gap-x-12 gap-y-4 border-t border-border pt-8 text-sm">
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Based
                </p>
                <p className="mt-1 text-foreground">{profile.location}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Status
                </p>
                <p className="mt-1 text-foreground">Available</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Studio
                </p>
                <p className="mt-1 font-serif-italic text-foreground">
                  {profile.studio}
                </p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Education
                </p>
                <p className="mt-1 text-foreground">SRM IST Trichy</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
