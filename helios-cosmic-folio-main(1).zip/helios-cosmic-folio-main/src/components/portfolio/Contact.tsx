import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, MapPin, Loader2 } from "lucide-react";
import { z } from "zod";
import { profile } from "@/data/portfolio";
import { supabase } from "@/integrations/supabase/client";

const socials = [
  { label: "Email", value: profile.email, href: `mailto:${profile.email}` },
  { label: "LinkedIn", value: "/in/hariprasad-gamedev", href: profile.linkedin },
  { label: "GitHub", value: "@hariprasad", href: profile.github },
];

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name is too long"),
  email: z.string().trim().email("Invalid email").max(255, "Email is too long"),
  subject: z.string().trim().max(200, "Subject is too long").optional(),
  message: z.string().trim().min(1, "Message is required").max(5000, "Message is too long"),
});

export function Contact() {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setStatus("sending");

    const form = e.currentTarget;
    const fd = new FormData(form);
    const raw = {
      name: String(fd.get("name") ?? ""),
      email: String(fd.get("email") ?? ""),
      subject: String(fd.get("subject") ?? ""),
      message: String(fd.get("message") ?? ""),
    };

    const parsed = contactSchema.safeParse(raw);
    if (!parsed.success) {
      setStatus("error");
      setError(parsed.error.issues[0]?.message ?? "Please check the form");
      return;
    }

    const { error: dbError } = await supabase
      .from("contact_submissions")
      .insert({
        name: parsed.data.name,
        email: parsed.data.email,
        subject: parsed.data.subject ?? null,
        message: parsed.data.message,
      });

    if (dbError) {
      setStatus("error");
      setError("Couldn't send right now. Please email me directly.");
      return;
    }

    setStatus("sent");
    form.reset();
    setTimeout(() => setStatus("idle"), 4500);
  };

  return (
    <section id="contact" className="border-t border-border bg-background">
      <div className="mx-auto max-w-7xl px-8 py-32">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-3">
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              (05) Contact
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
            className="md:col-span-9"
          >
            <h2 className="font-serif text-5xl leading-[1] text-foreground md:text-8xl">
              Let's build a <span className="font-serif-italic">world</span>
              <br />
              together.
            </h2>

            <div className="mt-16 grid gap-16 md:grid-cols-[1.3fr_1fr]">
              {/* Form */}
              <form onSubmit={onSubmit} className="space-y-8" noValidate>
                <div className="grid gap-8 md:grid-cols-2">
                  <Field label="Name" name="name" placeholder="Your name" maxLength={100} />
                  <Field label="Email" name="email" type="email" placeholder="you@studio.com" maxLength={255} />
                </div>
                <Field label="Subject" name="subject" placeholder="Project, role, or hello" required={false} maxLength={200} />
                <div>
                  <label className="block text-xs uppercase tracking-[0.25em] text-muted-foreground">
                    Message
                  </label>
                  <textarea
                    required
                    name="message"
                    rows={5}
                    maxLength={5000}
                    className="mt-3 w-full resize-none border-b border-border bg-transparent py-3 text-foreground outline-none transition-colors placeholder:text-muted-foreground/50 focus:border-foreground"
                    placeholder="Tell me about your project..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="group inline-flex items-center gap-3 border-b border-foreground pb-2 text-sm uppercase tracking-[0.25em] text-foreground disabled:opacity-60"
                >
                  {status === "sending" ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Sending...
                    </>
                  ) : status === "sent" ? (
                    "Message sent ✓"
                  ) : (
                    <>
                      Send message
                      <ArrowUpRight
                        size={16}
                        className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1"
                      />
                    </>
                  )}
                </button>

                {status === "error" && error && (
                  <p className="text-xs uppercase tracking-[0.2em] text-destructive">
                    {error}
                  </p>
                )}
                {status === "sent" && (
                  <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                    Thanks — I'll get back to you soon.
                  </p>
                )}
              </form>

              {/* Info */}
              <div className="space-y-10">
                <div>
                  <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
                    Reach me
                  </p>
                  <ul className="mt-6 space-y-4">
                    {socials.map((s) => (
                      <li key={s.label}>
                        <a
                          href={s.href}
                          target={s.href.startsWith("http") ? "_blank" : undefined}
                          rel="noreferrer"
                          className="group flex items-baseline justify-between gap-4 border-b border-border pb-3 text-foreground"
                        >
                          <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                            {s.label}
                          </span>
                          <span className="font-serif-italic text-base transition-opacity group-hover:opacity-60 md:text-lg">
                            {s.value}
                          </span>
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex items-start gap-3 text-sm text-foreground">
                  <MapPin size={16} className="mt-0.5 shrink-0" />
                  <span>
                    Based in {profile.location} ·{" "}
                    <span className="font-serif-italic">available</span>
                  </span>
                </div>

                <a
                  href={profile.cvUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-foreground bg-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-background transition-colors hover:bg-transparent hover:text-foreground"
                >
                  Download Resume
                  <ArrowUpRight size={14} />
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Footer wordmark */}
      <div className="overflow-hidden border-t border-border">
        <div className="mx-auto max-w-7xl px-8 py-16">
          <p className="font-serif text-[clamp(2.5rem,8vw,7rem)] leading-none text-foreground">
            Hariprasad
            <span className="font-serif-italic text-muted-foreground">.</span>
          </p>
          <div className="mt-8 flex flex-col items-start justify-between gap-4 text-xs uppercase tracking-[0.25em] text-muted-foreground md:flex-row">
            <span>© {new Date().getFullYear()} Hariprasad · {profile.studio}</span>
            <span>Crafted with intent</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  required = true,
  maxLength,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  maxLength?: number;
}) {
  return (
    <div>
      <label className="block text-xs uppercase tracking-[0.25em] text-muted-foreground">
        {label}
      </label>
      <input
        required={required}
        name={name}
        type={type}
        placeholder={placeholder}
        maxLength={maxLength}
        className="mt-3 w-full border-b border-border bg-transparent py-3 text-foreground outline-none transition-colors placeholder:text-muted-foreground/50 focus:border-foreground"
      />
    </div>
  );
}
