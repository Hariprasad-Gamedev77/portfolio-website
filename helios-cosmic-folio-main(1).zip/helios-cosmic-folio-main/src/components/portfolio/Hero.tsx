import { motion } from "framer-motion";
import { ArrowDown, FileText } from "lucide-react";
import { profile } from "@/data/portfolio";



export function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen w-full flex-col justify-center gap-16 overflow-hidden bg-background pt-32 pb-12"
    >
      {/* Main editorial title */}
      <div className="mx-auto w-full max-w-7xl px-8">
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="font-serif leading-[0.9] tracking-tight text-foreground"
        >
          <span className="block text-[clamp(3.5rem,11vw,11rem)]">Hariprasad,</span>
          <span className="block text-[clamp(3rem,9vw,9rem)] italic text-muted-foreground">
            level designer
          </span>
          <span className="block text-[clamp(3rem,9vw,9rem)]">
            &amp; world builder.
          </span>
        </motion.h1>
      </div>

      {/* Bottom row: lede + CV + scroll cue */}
      <div className="mx-auto w-full max-w-7xl px-8 pb-12">
        <div className="grid gap-12 border-t border-border pt-8 md:grid-cols-3">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="md:col-span-2 max-w-2xl text-base leading-relaxed text-foreground md:text-lg"
          >
            Founder, building <span className="font-serif-italic">Eclipse Chronicles</span> — a
            cinematic RPG in Unreal Engine 5. Passionate about pacing, sightlines,
            and the small decisions that make a level feel alive.
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col items-start gap-4 md:items-end"
          >
            <a
              href={profile.cvUrl}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-3 rounded-full border border-foreground bg-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-background transition-colors hover:bg-transparent hover:text-foreground"
            >
              <FileText size={14} />
              Download Resume
            </a>
            <a
              href="#work"
              className="group inline-flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-foreground"
            >
              <span className="border-b border-foreground pb-1 transition-opacity group-hover:opacity-60">
                See projects
              </span>
              <ArrowDown
                size={14}
                className="transition-transform group-hover:translate-y-1"
              />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
