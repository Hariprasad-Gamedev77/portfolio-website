import { useMemo } from "react";

interface VideoPlayerProps {
  src: string;
  poster?: string;
  title?: string;
  /** Loop muted autoplay (good for hero reels). Defaults to false (player with controls). */
  ambient?: boolean;
  className?: string;
  aspect?: "16/9" | "21/9" | "4/3";
}

/**
 * Universal video player.
 * - Detects YouTube / Vimeo URLs and embeds them in an iframe.
 * - Otherwise renders a native <video> with controls (MP4, WebM, etc.).
 * - `ambient` mode: muted, looping, autoplay — for background reels.
 */
export function VideoPlayer({
  src,
  poster,
  title,
  ambient = false,
  className = "",
  aspect = "16/9",
}: VideoPlayerProps) {
  const aspectClass =
    aspect === "21/9"
      ? "aspect-[21/9]"
      : aspect === "4/3"
        ? "aspect-[4/3]"
        : "aspect-video";

  const embed = useMemo(() => parseEmbed(src), [src]);

  return (
    <div
      className={`relative w-full overflow-hidden bg-black ${aspectClass} ${className}`}
    >
      {embed ? (
        <iframe
          src={embed}
          title={title ?? "Video player"}
          loading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
          className="absolute inset-0 h-full w-full"
        />
      ) : (
        <video
          src={src}
          poster={poster}
          controls={!ambient}
          autoPlay={ambient}
          muted={ambient}
          loop={ambient}
          playsInline
          preload={ambient ? "auto" : "metadata"}
          className="h-full w-full object-cover"
        />
      )}
    </div>
  );
}

function parseEmbed(url: string): string | null {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");

    // youtu.be/<id>
    if (host === "youtu.be") {
      const id = u.pathname.slice(1).split("/")[0];
      if (id) return `https://www.youtube.com/embed/${id}?rel=0`;
    }

    // youtube.com/watch?v=<id>  |  youtube.com/embed/<id>  |  youtube.com/shorts/<id>
    if (host === "youtube.com" || host === "m.youtube.com") {
      if (u.pathname === "/watch") {
        const id = u.searchParams.get("v");
        if (id) return `https://www.youtube.com/embed/${id}?rel=0`;
      }
      const m = u.pathname.match(/^\/(embed|shorts)\/([^/]+)/);
      if (m) return `https://www.youtube.com/embed/${m[2]}?rel=0`;
    }

    // vimeo.com/<id>
    if (host === "vimeo.com") {
      const id = u.pathname.split("/").filter(Boolean)[0];
      if (id && /^\d+$/.test(id)) return `https://player.vimeo.com/video/${id}`;
    }
    if (host === "player.vimeo.com") return url;

    return null;
  } catch {
    return null;
  }
}
