import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import type { Project } from "@/data/portfolio";

interface Props {
  project: Project;
  index: number;
}

export function ProjectCard({ project, index }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hovered, setHovered] = useState(false);

  const onEnter = () => {
    setHovered(true);
    videoRef.current?.play().catch(() => {});
  };
  const onLeave = () => {
    setHovered(false);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Link
        to="/projects/$projectId"
        params={{ projectId: project.id }}
        onMouseEnter={onEnter}
        onMouseLeave={onLeave}
        onFocus={onEnter}
        onBlur={onLeave}
        className="group block focus:outline-none"
      >
        <div className="mb-5 flex items-baseline justify-between border-b border-border pb-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
          <span className="flex items-center gap-3">
            <span>
              {String(index + 1).padStart(2, "0")} / {project.category}
            </span>
            {project.id === "eclipse-chronicles" && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-foreground/40 px-2 py-0.5 text-[0.6rem] tracking-[0.3em] text-foreground">
                <span className="h-1 w-1 rounded-full bg-foreground" />
                Flagship
              </span>
            )}
          </span>
          <span className="hidden md:inline">{project.duration}</span>
        </div>

        <div className="relative aspect-[4/3] w-full overflow-hidden bg-muted">
          <img
            src={project.thumbnail}
            alt={project.title}
            loading="lazy"
            className={`absolute inset-0 h-full w-full object-cover transition-all duration-700 ${
              hovered ? "scale-105 opacity-0" : "scale-100 opacity-100"
            }`}
          />
          <video
            ref={videoRef}
            src={project.heroVideo}
            muted
            loop
            playsInline
            preload="none"
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${
              hovered ? "opacity-100" : "opacity-0"
            }`}
          />
        </div>

        <div className="mt-6 flex items-start justify-between gap-6">
          <div>
            <h3 className="font-serif text-3xl leading-tight text-foreground md:text-5xl">
              {project.title}
            </h3>
            <p className="mt-2 text-sm text-muted-foreground">
              {project.engine}
            </p>
          </div>
          <span className="mt-2 inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-foreground text-foreground transition-all duration-500 group-hover:bg-foreground group-hover:text-background">
            <ArrowUpRight size={18} />
          </span>
        </div>
      </Link>
    </motion.div>
  );
}
