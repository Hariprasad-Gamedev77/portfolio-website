import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowUpRight, Award, FileText, X, FileType2 } from "lucide-react";
import { Navbar } from "@/components/portfolio/Navbar";
import { certifications, profile, type Certification } from "@/data/portfolio";

export const Route = createFileRoute("/certifications")({
  head: () => ({
    meta: [
      { title: "Certifications — Hariprasad | Level Designer" },
      {
        name: "description",
        content:
          "Certifications and continued learning by Hariprasad — Unreal Engine 5, Blueprints, C++, and game design.",
      },
      { property: "og:title", content: "Certifications — Hariprasad" },
      {
        property: "og:description",
        content: "Continued learning in Unreal Engine 5, Blueprints, and game design.",
      },
    ],
  }),
  component: CertificationsPage,
});

function isPdf(url: string) {
  return /\.pdf($|\?)/i.test(url);
}

function CertificationsPage() {
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      <main className="pt-32">
        <section className="mx-auto max-w-7xl px-8 pb-16">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft size={14} />
            Back to portfolio
          </Link>

          <div className="mt-10 grid gap-16 md:grid-cols-12">
            <div className="md:col-span-3">
              <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
                Certifications
              </p>
            </div>
            <div className="md:col-span-9">
              <h1 className="font-serif text-5xl leading-[1] text-foreground md:text-7xl">
                Continued <span className="font-serif-italic">learning.</span>
              </h1>
              <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
                A snapshot of the courses, workshops, and certifications that
                shape how I design and build games. Always more in progress.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={profile.cvUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-foreground bg-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-background transition-colors hover:bg-transparent hover:text-foreground"
                >
                  <FileText size={14} />
                  Download CV
                </a>
              </div>
            </div>
          </div>
        </section>

        <section className="border-t border-border">
          <div className="mx-auto max-w-7xl divide-y divide-border px-8">
            {certifications.map((c, idx) => (
              <CertificationRow
                key={c.title}
                cert={c}
                index={idx}
                onPreviewImage={(src) => setLightboxImg(src)}
              />
            ))}
          </div>
        </section>

        <section className="border-t border-border">
          <div className="mx-auto max-w-7xl px-8 py-24">
            <div className="grid gap-10 md:grid-cols-2 md:items-end">
              <h2 className="font-serif text-4xl leading-[1.05] text-foreground md:text-6xl">
                Want the full <span className="font-serif-italic">resume?</span>
              </h2>
              <div className="flex flex-wrap gap-6 md:justify-end">
                <a
                  href={profile.cvUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-2 border-b border-foreground pb-1 text-sm uppercase tracking-[0.25em] text-foreground"
                >
                  Download CV
                  <ArrowUpRight
                    size={16}
                    className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  />
                </a>
                <a
                  href={profile.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-2 border-b border-foreground pb-1 text-sm uppercase tracking-[0.25em] text-foreground"
                >
                  LinkedIn
                  <ArrowUpRight
                    size={16}
                    className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  />
                </a>
                <a
                  href={`mailto:${profile.email}`}
                  className="group inline-flex items-center gap-2 border-b border-foreground pb-1 text-sm uppercase tracking-[0.25em] text-foreground"
                >
                  Email me
                  <ArrowUpRight
                    size={16}
                    className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  />
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Lightbox */}
      {lightboxImg && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/95 p-6 backdrop-blur-sm"
          onClick={() => setLightboxImg(null)}
        >
          <button
            type="button"
            className="absolute right-6 top-6 inline-flex h-10 w-10 items-center justify-center rounded-full border border-foreground text-foreground"
            onClick={() => setLightboxImg(null)}
            aria-label="Close preview"
          >
            <X size={18} />
          </button>
          <img
            src={lightboxImg}
            alt="Certification preview"
            className="max-h-full max-w-full object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}

function CertificationRow({
  cert,
  index,
  onPreviewImage,
}: {
  cert: Certification;
  index: number;
  onPreviewImage: (src: string) => void;
}) {
  const proof = cert.proofUrl;
  const proofIsPdf = proof ? isPdf(proof) : false;

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.06 }}
      className="grid gap-6 py-10 md:grid-cols-12 md:gap-10 md:py-14"
    >
      <div className="md:col-span-2">
        <span className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
          {String(index + 1).padStart(2, "0")} / {cert.year}
        </span>
      </div>

      {/* Thumbnail / proof */}
      <div className="md:col-span-3">
        {proof && !proofIsPdf ? (
          <button
            type="button"
            onClick={() => onPreviewImage(proof)}
            className="group block aspect-[4/3] w-full overflow-hidden border border-border bg-muted"
            aria-label={`Preview ${cert.title} certificate`}
          >
            <img
              src={proof}
              alt={`${cert.title} certificate`}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          </button>
        ) : proof && proofIsPdf ? (
          <a
            href={proof}
            target="_blank"
            rel="noreferrer"
            className="group flex aspect-[4/3] w-full flex-col items-center justify-center gap-2 border border-border bg-muted text-muted-foreground transition-colors hover:bg-card hover:text-foreground"
          >
            <FileType2 size={28} />
            <span className="text-xs uppercase tracking-[0.2em]">View PDF</span>
          </a>
        ) : (
          <div className="flex aspect-[4/3] w-full items-center justify-center border border-dashed border-border text-muted-foreground">
            <Award size={28} />
          </div>
        )}
      </div>

      <div className="md:col-span-5">
        <h2 className="font-serif text-3xl text-foreground md:text-4xl">
          {cert.title}
        </h2>
        <p className="mt-2 text-sm uppercase tracking-[0.2em] text-muted-foreground">
          {cert.issuer}
        </p>
        {cert.description && (
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-foreground">
            {cert.description}
          </p>
        )}
      </div>

      <div className="flex items-start justify-start md:col-span-2 md:justify-end">
        {cert.credentialUrl ? (
          <a
            href={cert.credentialUrl}
            target="_blank"
            rel="noreferrer"
            className="group inline-flex items-center gap-2 border-b border-foreground pb-1 text-xs uppercase tracking-[0.25em] text-foreground"
          >
            Verify
            <ArrowUpRight
              size={14}
              className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
            />
          </a>
        ) : proof ? (
          <span className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
            {proofIsPdf ? "PDF on file" : "Image on file"}
          </span>
        ) : (
          <span className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
            On file
          </span>
        )}
      </div>
    </motion.article>
  );
}
