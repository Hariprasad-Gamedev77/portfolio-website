import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/portfolio/Navbar";
import { Hero } from "@/components/portfolio/Hero";
import { Projects } from "@/components/portfolio/Projects";
import { Skills } from "@/components/portfolio/Skills";
import { About } from "@/components/portfolio/About";
import { Experience } from "@/components/portfolio/Experience";
import { Marquee } from "@/components/portfolio/Marquee";
import { Contact } from "@/components/portfolio/Contact";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Hariprasad — Level Designer" },
      {
        name: "description",
        content:
          "Portfolio of Hariprasad — level designer building cinematic worlds in Unreal Engine 5.",
      },
      { property: "og:title", content: "Hariprasad — Level Designer" },
      {
        property: "og:description",
        content:
          "Cinematic level design and worldbuilding in Unreal Engine 5.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main>
        <Hero />
        <Projects />
        <Skills />
        <Marquee />
        <About />
        <Experience />
        <Contact />
      </main>
    </div>
  );
}

