import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowUpRight, FileText } from "lucide-react";
import { Navbar } from "@/components/portfolio/Navbar";
import { VideoPlayer } from "@/components/portfolio/VideoPlayer";
import {
  projects,
  profile,
  type Project,
  type MediaClip,
  type ProcessStep,
  type GalleryImage,
  type DesignTechnique,
} from "@/data/portfolio";

export const Route = createFileRoute("/projects/$projectId")({
  loader: ({ params }) => {
    const project = projects.find((p) => p.id === params.projectId);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.project;
    if (!p) return { meta: [{ title: "Project not found — Hariprasad" }] };
    return {
      meta: [
        { title: `${p.title} — Hariprasad | Level Designer` },
        { name: "description", content: p.description },
        { property: "og:title", content: `${p.title} — Hariprasad` },
        { property: "og:description", content: p.description },
        { property: "og:image", content: p.thumbnail },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: p.thumbnail },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-background px-4 text-center">
      <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">404</p>
      <h1 className="font-serif text-5xl text-foreground">
        Project <span className="font-serif-italic">not found.</span>
      </h1>
      <Link
        to="/"
        className="inline-flex items-center gap-2 border-b border-foreground pb-1 text-xs uppercase tracking-[0.25em] text-foreground"
      >
        <ArrowLeft size={14} /> Back to portfolio
      </Link>
    </div>
  ),
  component: ProjectDetailPage,
});

function ProjectDetailPage() {
  const { project } = Route.useLoaderData() as { project: Project };
  const idx = projects.findIndex((p) => p.id === project.id);
  const next = projects[(idx + 1) % projects.length];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />

      {/* (00) Title + trailer */}
      <section className="px-8 pb-16 pt-40">
        <div className="mx-auto max-w-7xl">
          <Link
            to="/"
            hash="work"
            className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft size={14} /> Index
          </Link>

          <div className="mt-12 grid gap-10 md:grid-cols-12">
            <div className="md:col-span-3">
              <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
                {project.category} · Case Study
              </p>
              <p className="mt-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
                ({String(idx + 1).padStart(2, "0")} /{" "}
                {String(projects.length).padStart(2, "0")})
              </p>
            </div>
            <div className="md:col-span-9">
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                className="font-serif text-[clamp(3rem,9vw,9rem)] leading-[0.95] text-foreground"
              >
                {project.title.split(" ").map((word, i, arr) => (
                  <span
                    key={i}
                    className={i === arr.length - 1 ? "font-serif-italic" : ""}
                  >
                    {word}
                    {i < arr.length - 1 ? " " : ""}
                  </span>
                ))}
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, delay: 0.15 }}
                className="mt-8 max-w-3xl text-lg leading-relaxed text-foreground md:text-xl"
              >
                {project.description}
              </motion.p>
            </div>
          </div>
        </div>
      </section>

      {/* Trailer / hero video */}
      <section className="px-8">
        <div className="mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2 }}
          >
            <VideoPlayer
              src={project.heroVideo}
              poster={project.thumbnail}
              title={`${project.title} — Trailer`}
              ambient
              aspect="16/9"
            />
          </motion.div>
          <p className="mt-4 text-xs uppercase tracking-[0.25em] text-muted-foreground">
            Reel 00 — Trailer · {project.title}
          </p>
        </div>
      </section>

      {/* Meta strip */}
      <section className="border-y border-border mt-24 bg-background">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-8 py-10 md:grid-cols-5">
          <MetaItem label="Role" value={project.role} />
          <MetaItem label="Engine" value={project.engine} />
          <MetaItem label="Timeline" value={project.duration} />
          <MetaItem label="Year" value={project.year} />
          <MetaItem label="Category" value={project.category} />
        </div>
      </section>

      {/* (01) Summary */}
      <Section number="01" eyebrow="Summary" heading={<>The <em className="font-serif-italic">brief.</em></>}>
        <p className="max-w-3xl text-lg leading-relaxed text-foreground md:text-xl">
          {project.summary}
        </p>
      </Section>

      {/* (02) Breakdown */}
      <Section number="02" eyebrow="Breakdown" heading={<>Challenge, approach, <em className="font-serif-italic">outcome.</em></>}>
        <div className="grid gap-12 md:grid-cols-3">
          <SummaryBlock label="Challenge" body={project.challenge} />
          <SummaryBlock label="Approach" body={project.approach} />
          <SummaryBlock label="Outcome" body={project.outcome} />
        </div>
      </Section>

      {/* (03) Level Overview — top-down map */}
      <Section number="03" eyebrow="Level Overview" heading={<>Pacing, <em className="font-serif-italic">readability,</em> and intent.</>}>
        <p className="max-w-3xl text-lg leading-relaxed text-foreground">
          {project.designIntent}
        </p>
        <div className="mt-12 aspect-[16/10] overflow-hidden bg-muted">
          <img
            src={project.topDownMapImage}
            alt={`${project.title} top-down map`}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <p className="mt-4 text-xs uppercase tracking-[0.25em] text-muted-foreground">
          Fig. 01 — Top-down blockout · {project.title}
        </p>
      </Section>

      {/* (04) Tension graph / playthrough */}
      {project.tensionGraphVideo && (
        <Section number="04" eyebrow="Tension Graph" heading={<>The <em className="font-serif-italic">playthrough.</em></>}>
          <p className="max-w-2xl text-base leading-relaxed text-muted-foreground">
            Annotated full playthrough mapping pacing beats to player tension —
            silence, signal, threat, release.
          </p>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="mt-12"
          >
            <VideoPlayer
              src={project.tensionGraphVideo}
              poster={project.thumbnail}
              title={`${project.title} — Tension Graph Playthrough`}
              aspect="16/9"
            />
          </motion.div>
        </Section>
      )}

      {/* (05) Design Techniques */}
      {project.designTechniques.length > 0 && (
        <Section number="05" eyebrow="Design Techniques" heading={<>The <em className="font-serif-italic">how.</em></>}>
          <div className="space-y-24">
            {project.designTechniques.map((t, i) => (
              <TechniqueRow key={t.title} technique={t} flipped={i % 2 === 1} />
            ))}
          </div>
        </Section>
      )}

      {/* (06) References */}
      {project.references.length > 0 && (
        <Section number="06" eyebrow="References" heading={<>What I <em className="font-serif-italic">looked at.</em></>}>
          <div className="grid gap-6 md:grid-cols-3">
            {project.references.map((ref, i) => (
              <figure key={ref.src + i}>
                <div className="aspect-[4/3] overflow-hidden bg-muted">
                  <img
                    src={ref.src}
                    alt={ref.caption ?? `Reference ${i + 1}`}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                </div>
                {ref.caption && (
                  <figcaption className="mt-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                    {ref.caption}
                  </figcaption>
                )}
              </figure>
            ))}
          </div>
        </Section>
      )}

      {/* (07) Sketches */}
      {project.sketches.length > 0 && (
        <Section number="07" eyebrow="Sketching" heading={<>Paper <em className="font-serif-italic">first.</em></>}>
          <div className="grid gap-6 md:grid-cols-2">
            {project.sketches.map((s, i) => (
              <figure key={s.src + i}>
                <div className="aspect-[4/3] overflow-hidden bg-muted">
                  <img
                    src={s.src}
                    alt={s.caption ?? `Sketch ${i + 1}`}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                </div>
                {s.caption && (
                  <figcaption className="mt-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                    {s.caption}
                  </figcaption>
                )}
              </figure>
            ))}
          </div>
        </Section>
      )}

      {/* (08) Blockout process */}
      {project.blockoutVideo && (
        <Section number="08" eyebrow="Blockout Process" heading={<>From paper <em className="font-serif-italic">to engine.</em></>}>
          {project.blockoutNotes && (
            <p className="max-w-2xl text-base leading-relaxed text-muted-foreground">
              {project.blockoutNotes}
            </p>
          )}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="mt-12"
          >
            <VideoPlayer
              src={project.blockoutVideo}
              poster={project.thumbnail}
              title={`${project.title} — Blockout`}
              aspect="16/9"
            />
          </motion.div>
        </Section>
      )}

      {/* (09) Process steps */}
      {project.process.length > 0 && (
        <Section number="09" eyebrow="Step by Step" heading={<>The <em className="font-serif-italic">workflow.</em></>}>
          <div className="space-y-32">
            {project.process.map((step, i) => (
              <ProcessRow key={step.label} step={step} flipped={i % 2 === 1} />
            ))}
          </div>
        </Section>
      )}

      {/* (10) Mechanics clips */}
      {project.gameplayClips.length > 0 && (
        <Section number="10" eyebrow="In Engine" heading={<>Mechanics <em className="font-serif-italic">&amp; scripting.</em></>}>
          <div className="grid gap-x-10 gap-y-20 md:grid-cols-2">
            {project.gameplayClips.map((clip: MediaClip, i) => (
              <div key={clip.title}>
                <p className="mb-4 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                  Clip {String(i + 1).padStart(2, "0")}
                </p>
                <VideoPlayer
                  src={clip.videoUrl}
                  poster={clip.poster ?? project.thumbnail}
                  title={clip.title}
                  aspect="16/9"
                />
                <h3 className="mt-6 font-serif text-3xl text-foreground">{clip.title}</h3>
                {clip.description && (
                  <p className="mt-2 text-sm text-muted-foreground">{clip.description}</p>
                )}
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* (11) Environmental Storytelling */}
      {project.environmentalStorytelling.length > 0 && (
        <Section number="11" eyebrow="Environmental Storytelling" heading={<>Stories told <em className="font-serif-italic">in props.</em></>}>
          {project.environmentalStorytellingNotes && (
            <p className="max-w-2xl text-base leading-relaxed text-muted-foreground">
              {project.environmentalStorytellingNotes}
            </p>
          )}
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {project.environmentalStorytelling.map((img, i) => (
              <figure key={img.src + i}>
                <div className="aspect-[4/3] overflow-hidden bg-muted">
                  <img
                    src={img.src}
                    alt={img.caption ?? `Environmental detail ${i + 1}`}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                </div>
                {img.caption && (
                  <figcaption className="mt-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                    {img.caption}
                  </figcaption>
                )}
              </figure>
            ))}
          </div>
        </Section>
      )}

      {/* (12) Gallery */}
      {project.gallery.length > 0 && (
        <Section number="12" eyebrow="Gallery" heading={<>Selected <em className="font-serif-italic">stills.</em></>}>
          <div className="grid gap-6 md:grid-cols-2">
            {project.gallery.map((img: GalleryImage, i) => (
              <motion.figure
                key={img.src + i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.7, delay: (i % 2) * 0.1 }}
                className={i === 0 ? "md:col-span-2" : ""}
              >
                <div
                  className={`overflow-hidden bg-muted ${
                    i === 0 ? "aspect-[21/9]" : "aspect-[4/3]"
                  }`}
                >
                  <img
                    src={img.src}
                    alt={img.caption ?? `${project.title} still ${i + 1}`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 hover:scale-[1.02]"
                  />
                </div>
                {img.caption && (
                  <figcaption className="mt-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                    {String(i + 1).padStart(2, "0")} — {img.caption}
                  </figcaption>
                )}
              </motion.figure>
            ))}
          </div>
        </Section>
      )}

      {/* (13) Reflection */}
      <Section number="13" eyebrow="Reflection" heading={<>What I <em className="font-serif-italic">took with me.</em></>}>
        <p className="font-serif text-3xl leading-[1.2] text-foreground md:text-5xl">
          <span className="font-serif-italic">"</span>
          {project.reflection ??
            "Every level I ship leaves me with a question I didn't know to ask when I started — that's the part I keep coming back for"}
          <span className="font-serif-italic">."</span>
        </p>
        <p className="mt-8 text-xs uppercase tracking-[0.25em] text-muted-foreground">
          — Hariprasad · {project.year}
        </p>
        <div className="mt-12 flex flex-wrap gap-4">
          <a
            href={profile.cvUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-foreground bg-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-background transition-colors hover:bg-transparent hover:text-foreground"
          >
            <FileText size={14} /> Download CV
          </a>
          <Link
            to="/"
            hash="contact"
            className="inline-flex items-center gap-2 rounded-full border border-foreground px-5 py-2.5 text-xs uppercase tracking-[0.25em] text-foreground transition-colors hover:bg-foreground hover:text-background"
          >
            Get in touch
          </Link>
        </div>
      </Section>

      {/* Next project */}
      <section className="border-t border-border">
        <Link
          to="/projects/$projectId"
          params={{ projectId: next.id }}
          className="group block px-8 py-24 transition-colors hover:bg-card"
        >
          <div className="mx-auto max-w-7xl">
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              Next Project — ({String(((idx + 1) % projects.length) + 1).padStart(2, "0")})
            </p>
            <div className="mt-6 flex items-end justify-between gap-6">
              <h2 className="font-serif text-5xl leading-none text-foreground md:text-8xl">
                {next.title.split(" ").map((word, i, arr) => (
                  <span
                    key={i}
                    className={i === arr.length - 1 ? "font-serif-italic" : ""}
                  >
                    {word}
                    {i < arr.length - 1 ? " " : ""}
                  </span>
                ))}
              </h2>
              <span className="inline-flex h-16 w-16 shrink-0 items-center justify-center rounded-full border border-foreground text-foreground transition-all duration-500 group-hover:bg-foreground group-hover:text-background">
                <ArrowUpRight size={22} />
              </span>
            </div>
          </div>
        </Link>
      </section>
    </div>
  );
}

function Section({
  number,
  eyebrow,
  heading,
  children,
}: {
  number: string;
  eyebrow: string;
  heading: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="border-t border-border px-8 py-32">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-3">
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              ({number}) {eyebrow}
            </p>
          </div>
          <div className="md:col-span-9">
            <h2 className="font-serif text-4xl leading-[1.05] text-foreground md:text-6xl">
              {heading}
            </h2>
            <div className="mt-12">{children}</div>
          </div>
        </div>
      </div>
    </section>
  );
}

function MetaItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
        {label}
      </p>
      <p className="mt-2 font-serif text-xl text-foreground md:text-2xl">{value}</p>
    </div>
  );
}

function SummaryBlock({ label, body }: { label: string; body: string }) {
  return (
    <div className="border-t border-border pt-6">
      <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">{label}</p>
      <p className="mt-4 text-base leading-relaxed text-foreground">{body}</p>
    </div>
  );
}

function ProcessRow({ step, flipped }: { step: ProcessStep; flipped: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8 }}
      className="grid items-center gap-12 md:grid-cols-12"
    >
      <div className={`md:col-span-7 ${flipped ? "md:order-2" : ""}`}>
        {step.videoUrl ? (
          <VideoPlayer src={step.videoUrl} poster={step.image} title={step.title} aspect="4/3" />
        ) : step.image ? (
          <div className="aspect-[4/3] overflow-hidden bg-muted">
            <img
              src={step.image}
              alt={step.title}
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </div>
        ) : null}
      </div>
      <div className={`md:col-span-5 ${flipped ? "md:order-1" : ""}`}>
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
          {step.label}
        </p>
        <h3 className="mt-4 font-serif text-3xl leading-[1.1] text-foreground md:text-5xl">
          {step.title}
        </h3>
        <p className="mt-6 text-base leading-relaxed text-foreground">{step.body}</p>
      </div>
    </motion.div>
  );
}

function TechniqueRow({
  technique,
  flipped,
}: {
  technique: DesignTechnique;
  flipped: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8 }}
      className="grid items-center gap-10 md:grid-cols-12"
    >
      <div className={`md:col-span-7 ${flipped ? "md:order-2" : ""}`}>
        {technique.videoUrl ? (
          <VideoPlayer src={technique.videoUrl} poster={technique.image} title={technique.title} aspect="16/9" />
        ) : technique.image ? (
          <div className="aspect-[16/10] overflow-hidden bg-muted">
            <img
              src={technique.image}
              alt={technique.title}
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </div>
        ) : null}
      </div>
      <div className={`md:col-span-5 ${flipped ? "md:order-1" : ""}`}>
        <h3 className="font-serif text-3xl leading-[1.1] text-foreground md:text-4xl">
          {technique.title}
        </h3>
        <p className="mt-6 text-base leading-relaxed text-foreground">{technique.body}</p>
      </div>
    </motion.div>
  );
}
